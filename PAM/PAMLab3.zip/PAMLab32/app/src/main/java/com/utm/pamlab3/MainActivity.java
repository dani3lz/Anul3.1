package com.utm.pamlab3;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView mylist;
    ArrayList<String> titles;
    ArrayList<String> links;
    ArrayList<String> titlesXML;
    ArrayList<String> linksXML;
    String urlCheck;
    boolean fromMenu = false;
    boolean fromSave = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        titlesXML = new ArrayList<String>();
        linksXML = new ArrayList<String>();
        titles = new ArrayList<String>();
        links = new ArrayList<String>();

        // Read XML
        readFromXml();

        fromMenu = getIntent().getBooleanExtra("FromMenu", false);
        fromSave = getIntent().getBooleanExtra("FromSave", false);

        if (fromSave) {
            boolean saved = getIntent().getBooleanExtra("FromSaveSelect", false);
            if (saved) {
                Toast.makeText(MainActivity.this, "Successfully saved!", Toast.LENGTH_SHORT).show();
            }

            titles = getIntent().getStringArrayListExtra("titles");
            links = getIntent().getStringArrayListExtra("links");
        }

        if (!fromMenu && !fromSave) {
            Intent intent = new Intent(MainActivity.this, MenuActivity.class);
            startActivity(intent);
        }
        else {
            urlCheck = getIntent().getStringExtra("url");
        }

        mylist = findViewById(R.id.listCatalogID);
        Button backbtn = findViewById(R.id.backCatelogbtn);
        Button savebtn = findViewById(R.id.savebtn);

        backbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivity = new Intent(MainActivity.this, MenuActivity.class);
                startActivity(changeActivity);
            }
        });

        savebtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivity = new Intent(MainActivity.this, SaveActivity.class);
                changeActivity.putStringArrayListExtra("titles", titles);
                changeActivity.putStringArrayListExtra("links", links);
                changeActivity.putStringArrayListExtra("titlesXML", titlesXML);
                changeActivity.putStringArrayListExtra("linksXML", linksXML);
                changeActivity.putExtra("url", urlCheck);
                startActivity(changeActivity);
            }
        });

        mylist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Uri uri = Uri.parse(links.get(position));
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);

            }
        });

        if(!fromSave) {
            new ProcessInBackground().execute();
        }
        else {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, titles);
            mylist.setAdapter(adapter);
        }

    }

    public InputStream getInputStream(URL url){
        try {
            return url.openConnection().getInputStream();
        }
        catch(IOException e){
            System.out.println(e);
            return null;
        }
    }

    public class ProcessInBackground extends AsyncTask<Integer, Void, Exception>{

        ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);
        Exception exception = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog.setMessage("Loading RSS feed...");
            progressDialog.show();
        }

        @Override
        protected Exception doInBackground(Integer... integers) {

            try {

                URL url = new URL(urlCheck);

                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(false);

                XmlPullParser xpp = factory.newPullParser();
                xpp.setInput(getInputStream(url), "UTF_8");

                boolean insideItem = false;

                int eventType = xpp.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT){
                    if (eventType == XmlPullParser.START_TAG){
                        if(xpp.getName().equals("item")){
                            insideItem = true;
                        }
                        else if (xpp.getName().equalsIgnoreCase("title")){
                            if(insideItem){
                                titles.add(xpp.nextText());
                            }
                        }
                        else if (xpp.getName().equalsIgnoreCase("link")){
                            if(insideItem){
                                links.add(xpp.nextText());
                            }
                        }
                    }
                    else if (eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("item")){
                        insideItem = false;
                    }

                    eventType = xpp.next();
                }

            }
            catch (MalformedURLException e){
                exception = e;
            }
            catch (XmlPullParserException e){
                exception = e;
            }
            catch (IOException e){
                exception = e;
            }
            System.out.println(exception);
            return exception;
        }

        @Override
        protected void onPostExecute(Exception e) {
            super.onPostExecute(e);
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, titles);
            mylist.setAdapter(adapter);

            progressDialog.dismiss();
        }
    }

    // ---------------------------------------------------------------------------------------------

    public void readFromXml(){
        XmlPullParserFactory parserFactory;
        try {
            FileInputStream is = new FileInputStream(getFilesDir() + "/rssItems.xml");
            parserFactory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = parserFactory.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(is, null);
            processParsing(parser);

        } catch (XmlPullParserException e) {

        } catch (IOException e) {
        }
    }

    private void processParsing(XmlPullParser parser) throws IOException, XmlPullParserException{
        int eventType = parser.getEventType();

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String eltName = null;
            switch (eventType) {
                case XmlPullParser.START_TAG:
                    eltName = parser.getName();

                    if ("item".equals(eltName)) {

                    } else if (true) {
                        if ("title".equals(eltName)) {
                            titlesXML.add(parser.nextText());

                        } else if ("link".equals(eltName)) {
                            linksXML.add(parser.nextText());
                        }
                    }
                    break;
            }

            eventType = parser.next();
        }
    }
}