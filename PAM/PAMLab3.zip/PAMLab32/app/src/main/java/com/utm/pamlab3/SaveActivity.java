package com.utm.pamlab3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Xml;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import org.xmlpull.v1.XmlSerializer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;

public class SaveActivity extends AppCompatActivity {
    ListView mylist;
    ArrayList<String> titles;
    ArrayList<String> links;
    ArrayList<String> titlesXML;
    ArrayList<String> linksXML;
    String url;
    int poss = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save);
        getSupportActionBar().hide();

        mylist = findViewById(R.id.listSaveID);
        Button backSavebtn = findViewById(R.id.backSavebtn);
        Button selectbtn = findViewById(R.id.selectbtn);
        mylist.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        titles = getIntent().getStringArrayListExtra("titles");
        links = getIntent().getStringArrayListExtra("links");
        titlesXML = getIntent().getStringArrayListExtra("titlesXML");
        linksXML = getIntent().getStringArrayListExtra("linksXML");
        url = getIntent().getStringExtra("url");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(SaveActivity.this, android.R.layout.simple_list_item_single_choice, titles);
        mylist.setAdapter(adapter);

        boolean FromCatalog = getIntent().getBooleanExtra("FromCatalog", false);

        mylist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                poss = position;
            }
        });

        backSavebtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivity = new Intent(SaveActivity.this, MainActivity.class);
                changeActivity.putStringArrayListExtra("titles", titles);
                changeActivity.putStringArrayListExtra("links", links);
                changeActivity.putExtra("FromSave", true);
                startActivity(changeActivity);
            }
        });

        selectbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(poss == -1){
                    Toast.makeText(SaveActivity.this, "Select an item", Toast.LENGTH_SHORT).show();
                }
                else {
                    if(!FromCatalog) {
                        String title = titles.get(poss);
                        String link = links.get(poss);
                        titlesXML.add(title);
                        linksXML.add(link);
                    }
                    else {
                        ArrayList<String> newTitles = new ArrayList<String>();
                        ArrayList<String> newLinks = new ArrayList<String>();
                        for(int i = 0; i < titlesXML.size(); i++){
                            if(i == poss){
                            }
                            else {
                                newTitles.add(titlesXML.get(i));
                                newLinks.add(linksXML.get(i));
                            }
                        }
                        titlesXML.clear();
                        linksXML.clear();
                        titlesXML = newTitles;
                        linksXML = newLinks;
                    }
                    writeToXml();
                    if(!FromCatalog) {
                        Intent changeActivity = new Intent(SaveActivity.this, MainActivity.class);
                        changeActivity.putStringArrayListExtra("titles", titles);
                        changeActivity.putStringArrayListExtra("links", links);
                        changeActivity.putExtra("FromSave", true);
                        changeActivity.putExtra("FromSaveSelect", true);
                        startActivity(changeActivity);
                    }
                    else {
                        Intent changeActivity = new Intent(SaveActivity.this, CatalogActivity.class);
                        startActivity(changeActivity);
                    }
                }
            }
        });


    }


// -------------------------------------------------------------------------------------------------

    public void writeToXml(){
        try {
            FileOutputStream fileos = new FileOutputStream(getFilesDir() + "/rssItems.xml");
            XmlSerializer xmlSerializer = Xml.newSerializer();
            StringWriter writer = new StringWriter();
            xmlSerializer.setOutput(writer);

            xmlSerializer.startDocument("UTF-8", true);
            xmlSerializer.setFeature("http://xmlpull.org/v1/doc/features.html#indent-output", true);

            xmlSerializer.startTag("", "Items");

            for(int i = 0; i < titlesXML.size(); i++) {

                xmlSerializer.startTag("", "item");

                xmlSerializer.startTag("", "title");
                xmlSerializer.text(titlesXML.get(i));
                xmlSerializer.endTag("", "title");

                xmlSerializer.startTag("", "link");
                xmlSerializer.text(linksXML.get(i));
                xmlSerializer.endTag("", "link");

                xmlSerializer.endTag("", "item");
            }

            xmlSerializer.endTag("", "Items");

            xmlSerializer.endDocument();
            xmlSerializer.flush();

            String dataWrite = writer.toString();

            fileos.write(dataWrite.getBytes());
            fileos.close();
        }
        catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (IllegalArgumentException e) {
            // TODO Auto-generated catch block

            e.printStackTrace();
        }
        catch (IllegalStateException e) {
            // TODO Auto-generated catch block

            e.printStackTrace();
        }
        catch (IOException e) {
            // TODO Auto-generated catch block

            e.printStackTrace();
        }
    }
}