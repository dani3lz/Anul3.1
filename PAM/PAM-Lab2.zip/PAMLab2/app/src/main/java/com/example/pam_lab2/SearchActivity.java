package com.example.pam_lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {
    ArrayList<String> titleEvents = new ArrayList<>();
    ArrayList<String> descriptionEvents = new ArrayList<>();
    ArrayList<String> timeEvents = new ArrayList<>();
    ArrayList<String> dateEvents = new ArrayList<>();
    ArrayList<String> titleSearch = new ArrayList<>();
    ArrayList<String> timeSearch = new ArrayList<>();
    ArrayList<String> dateSearch = new ArrayList<>();
    ArrayList<Integer> titleIndex = new ArrayList<>();
    ArrayList<Integer> selected = new ArrayList<>();
    String dateSelected;
    boolean existItem = false;
    Button selectbtn;
    ListView listSearch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        getSupportActionBar().hide();

        selectbtn = findViewById(R.id.btnSelect);
        listSearch = findViewById(R.id.searchList);

        titleEvents = getIntent().getStringArrayListExtra("eventsTitle");
        descriptionEvents = getIntent().getStringArrayListExtra("eventsDescription");
        timeEvents = getIntent().getStringArrayListExtra("eventsTime");
        dateEvents = getIntent().getStringArrayListExtra("eventsDate");
        titleSearch = getIntent().getStringArrayListExtra("titlesSearch");
        timeSearch = getIntent().getStringArrayListExtra("timeSearch");
        dateSearch = getIntent().getStringArrayListExtra("dateSearch");
        titleIndex = getIntent().getIntegerArrayListExtra("titleIndex");


        listSearch.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        showEvents();

        selectbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (selected.size() == 0) {
                    Intent changeActivityFinal = new Intent(SearchActivity.this, MainActivity.class);
                    startActivity(changeActivityFinal);
                } else {
                    String titleSelect = titleSearch.get(selected.get(0));
                    String timeSelected = timeSearch.get(selected.get(0));
                    String dateSelectedd = dateSearch.get(selected.get(0));
                    for(int i = 0; i < titleEvents.size(); i++){
                        if(titleEvents.get(i).equals(titleSelect) && timeEvents.get(i).equals(timeSelected) && dateEvents.get(i).equals(dateSelectedd)){
                            dateSelected = dateEvents.get(i);
                        }
                    }

                    Intent changeActivityFinal = new Intent(SearchActivity.this, MainActivity.class);
                    changeActivityFinal.putStringArrayListExtra("eventsTitle", titleEvents);
                    changeActivityFinal.putStringArrayListExtra("eventsDescription", descriptionEvents);
                    changeActivityFinal.putStringArrayListExtra("eventsTime", timeEvents);
                    changeActivityFinal.putStringArrayListExtra("eventsDate", dateEvents);
                    changeActivityFinal.putExtra("dateSelected", dateSelected);
                    changeActivityFinal.putExtra("FromSearch", true);
                    startActivity(changeActivityFinal);
                }


            }
        });


        listSearch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int nr = position;
                if (selected.size() == 0) {
                    existItem = false;
                } else {
                    for (int i = 0; i < selected.size(); i++) {
                        if (selected.get(i).equals(nr)) {
                            selected.remove(i);
                            existItem = true;
                            break;
                        } else {
                            existItem = false;
                        }
                    }
                }

                if (!existItem) {
                    selected.add(nr);
                }

            }
        });
    }

        public void showEvents(){
            ArrayList<String> eventClick = new ArrayList<>();

            for(int i = 0; i < titleIndex.size(); i++){
                String date = dateEvents.get(titleIndex.get(i));
                String[] dateArray = date.split("/");
                int dayNr = Integer.parseInt(dateArray[0]);
                int monthNr = Integer.parseInt(dateArray[1]) + 1;
                int yearNr = Integer.parseInt(dateArray[2]);
                date = dayNr+"/"+monthNr+"/"+yearNr;
                String shortName = titleEvents.get(titleIndex.get(i)) + " - " + timeEvents.get(titleIndex.get(i)) + " - " + date;
                eventClick.add(shortName);
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(SearchActivity.this,
                    android.R.layout.simple_list_item_single_choice, eventClick);

            listSearch.setAdapter(adapter);
        }


}