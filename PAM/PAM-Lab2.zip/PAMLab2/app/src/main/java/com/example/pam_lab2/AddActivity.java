package com.example.pam_lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

public class AddActivity extends AppCompatActivity {
    DatePickerDialog.OnDateSetListener setListener;
    TimePickerDialog.OnTimeSetListener setListener2;
    ArrayList<String> eventsTitleAdd = new ArrayList<>();
    ArrayList<String> eventsDescriptionAdd = new ArrayList<>();
    ArrayList<String> eventsTimeAdd = new ArrayList<>();
    ArrayList<String> eventsDatesAdd = new ArrayList<>();
    boolean fromMain = false;
    boolean fromUpdateBtn = false;
    boolean fromUpdate = false;
    String titleU,descriptionU,timeU,dateU;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        getSupportActionBar().hide();
        Button btnCancel = findViewById(R.id.btnCancel);
        Button btnNext = findViewById(R.id.btnNext);
        TextView dateView = findViewById(R.id.dateView);
        TextView time = findViewById(R.id.timeEdit);
        EditText title = findViewById(R.id.textTitle);
        EditText description = findViewById(R.id.textDescription);

        fromMain = getIntent().getBooleanExtra("FromMain", false);
        fromUpdateBtn = getIntent().getBooleanExtra("FromUpdateBtn", false);
        fromUpdate = getIntent().getBooleanExtra("FromUpdate", false);

        if(fromUpdateBtn){
            eventsTitleAdd = getIntent().getStringArrayListExtra("eventsTitle");
            eventsDescriptionAdd = getIntent().getStringArrayListExtra("eventsDescription");
            eventsTimeAdd = getIntent().getStringArrayListExtra("eventsTime");
            eventsDatesAdd = getIntent().getStringArrayListExtra("eventsDate");

            timeU = getIntent().getStringExtra("timeForChange");
            dateU = getIntent().getStringExtra("dateForChange");
            titleU = getIntent().getStringExtra("titleForChange");
            descriptionU = getIntent().getStringExtra("descForChange");

            String[] dateArray = dateU.split("/");

            int dayNr = Integer.parseInt(dateArray[0]);
            int monthNr = Integer.parseInt(dateArray[1]);
            int yearNr = Integer.parseInt(dateArray[2]);
            monthNr = monthNr + 1;

            dateU = dayNr+"/"+monthNr+"/"+yearNr;

            dateView.setText(dateU);
            time.setText(timeU);
            title.setText(titleU);
            description.setText(descriptionU);

            btnCancel.setVisibility(View.INVISIBLE);
        }


        if(fromMain) {
            eventsTitleAdd = getIntent().getStringArrayListExtra("eventsTitle");
            eventsDescriptionAdd = getIntent().getStringArrayListExtra("eventsDescription");
            eventsTimeAdd = getIntent().getStringArrayListExtra("eventsTime");
            eventsDatesAdd = getIntent().getStringArrayListExtra("eventsDate");

        }

        if(fromUpdate) {
            timeU = getIntent().getStringExtra("timeU");
            dateU = getIntent().getStringExtra("dateU");
            titleU = getIntent().getStringExtra("titleU");
            descriptionU = getIntent().getStringExtra("descriptionU");
            if (timeU.equals("") || dateU.equals("") || titleU.equals("") || descriptionU.equals("")) {

            } else {
                dateView.setText(dateU);
                time.setText(timeU);
                title.setText(titleU);
                description.setText(descriptionU);
            }

        }

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);
        final int hour = calendar.get(Calendar.HOUR_OF_DAY);
        final int minute = calendar.get(Calendar.MINUTE);

        dateView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        AddActivity.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        setListener,year,month,day);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });

        time.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(
                        AddActivity.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth, setListener2, hour, minute, true);
                timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                timePickerDialog.show();
            }
        });

        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                String date = day+"/"+month+"/"+year;
                dateView.setText(date);
            }
        };

        setListener2 = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int hour, int minute) {
                if(minute < 10){
                    String timechar = hour+":0"+minute;
                    time.setText(timechar);
                }
                else{
                    String timechar = hour+":"+minute;
                    time.setText(timechar);
                }

            }
        };


        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivityToMain = new Intent(AddActivity.this, MainActivity.class);
                changeActivityToMain.putStringArrayListExtra("eventsTitle", eventsTitleAdd);
                changeActivityToMain.putStringArrayListExtra("eventsDescription", eventsDescriptionAdd);
                changeActivityToMain.putStringArrayListExtra("eventsTime", eventsTimeAdd);
                changeActivityToMain.putStringArrayListExtra("eventsDate", eventsDatesAdd);
                startActivity(changeActivityToMain);
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(title.getText().toString().equals("") || dateView.getText().toString().equals("") || time.getText().toString().equals("") ){
                    Toast.makeText(AddActivity.this, "Toate spatiile sunt obligatorii.", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent changeActivityToUpdate = new Intent(AddActivity.this, UpdateActivity.class);
                    changeActivityToUpdate.putExtra("date", dateView.getText().toString());
                    changeActivityToUpdate.putExtra("time", time.getText().toString());
                    changeActivityToUpdate.putExtra("title", title.getText().toString());
                    changeActivityToUpdate.putExtra("description", description.getText().toString());
                    changeActivityToUpdate.putStringArrayListExtra("eventsTitle", eventsTitleAdd);
                    changeActivityToUpdate.putStringArrayListExtra("eventsDescription", eventsDescriptionAdd);
                    changeActivityToUpdate.putStringArrayListExtra("eventsTime", eventsTimeAdd);
                    changeActivityToUpdate.putStringArrayListExtra("eventsDate", eventsDatesAdd);
                    changeActivityToUpdate.putExtra("FromAdd", true);

                    startActivity(changeActivityToUpdate);
                }
            }
        });

    }
}