package com.example.pam_lab2;

public class Event {
    public String title, description, time, date;

    Event(){}

    Event(String title, String description, String time, String date){
        this.title = title;
        this.description = description;
        this.time = time;
        this.date = date;
    }

    public String getTitle(){
        return title;
    }

    public String getDescription(){
        return description;
    }

    public String getTime(){
        return time;
    }

    public String getDate() {
        return date;
    }
}
